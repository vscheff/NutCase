# Mocked GUI test data

`recorded_source.json` records the Phase 4 FC00AAB09748 native source catalog,
analysis, configuration and review data. It exercises the existing source-bound
schema and warning presentation with realistic data. Project-root paths use a
placeholder so the fixture is portable.

`../fixture.py` constructs an isolated manifest/history and a blank PDF plus
placeholder FCStd bytes for fast widget, path and export-checksum tests. Its
verification flags are recorded test inputs, not fresh CAD/PDF verification.
These files must never be used as engineering deliverables. Real FreeCAD and
PDF behavior is covered separately by the existing native/PDF suites and the
six-case `scripts/validate_phase5.py` integration matrix.

The fast GUI suite does not depend on prior generated `output/phase4/` files.
