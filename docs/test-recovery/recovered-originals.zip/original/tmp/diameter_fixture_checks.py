"""Independent native cylinder fixtures exercising physical arrow/text clearance."""
import json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ['FREECAD_USER_HOME']=str(ROOT/'tmp/freecad-runtime')
import FreeCAD as App,Part
from fastener_drawing.views import initialize_gui,wait_for_views
from fastener_drawing.dimensions import set_presentation,presentation_record
from fastener_drawing.references import inventory
from fastener_drawing.svg_placement import arrow_bounds,diameter_arrow_checks,ArrowTextCollision
from fastener_drawing.comprehensive import settle_placement
from fastener_drawing.template import make_template
Gui,TD=initialize_gui()
area={'left':15,'right':415,'top':25,'bottom':190}
template=ROOT/'tmp/diameter-fixture-template.svg'
layout={'width_mm':431.8,'height_mm':279.4,'sheet':'ANSI-B','content_area_top_origin_mm':area,
        'positions':{'right_end':{'x_mm':200,'y_mm':140}}}
make_template(template,{**layout,'scale_label':'Fixture'},'Independent native cylinder','2026-10-13',False)
results=[]
for diameter,scale in [(4,2),(9.5,1),(9.5,2),(9.6,2),(20,2),(9.5,5)]:
    doc=App.newDocument('ArrowFixture')
    source=doc.addObject('PartDesign::Feature','Cylinder');source.Shape=Part.makeCylinder(diameter/2,8)
    page=doc.addObject('TechDraw::DrawPage','DrawingPage');page.Scale=scale
    svg=doc.addObject('TechDraw::DrawSVGTemplate','Template');svg.Template=str(template);page.Template=svg
    view=doc.addObject('TechDraw::DrawViewPart','RightEnd');view.Source=[source]
    view.Direction=App.Vector(0,0,1);view.X=200;view.Y=140;page.addView(view);page.ViewObject.show()
    wait_for_views(doc,[view])
    # Select by native analytic center/radius, not a sample-dependent EdgeN.
    candidates=[e for e in inventory(view) if isinstance(e['edge'].Curve,Part.Circle)
                and abs(e['edge'].Curve.Radius-diameter/2)<1e-8]
    assert candidates
    dim=doc.addObject('TechDraw::DrawViewDimension','Diameter');dim.Type='Diameter'
    dim.MeasureType='Projected';dim.References2D=[(view,[candidates[0]['name']])];page.addView(dim)
    set_presentation(dim,'flange_diameter');dim.X=0;dim.Y=diameter*scale/2+16
    wait_for_views(doc,[view])
    report={'status':'created','object_name':dim.Name,'format_spec':dim.FormatSpec,
            'view_role':'right_end','candidate':{'kind':'diameter'},'presentation':presentation_record(dim),
            'position_relative_to_view_mm':[dim.X.Value,dim.Y.Value]}
    reports={'fixture':report}
    fixture_svg=ROOT/'tmp/diameter-fixture.svg';TD.exportPageAsSvg(page,str(fixture_svg))
    baseline_collision=False
    try:diameter_arrow_checks(doc,reports,fixture_svg)
    except ArrowTextCollision:baseline_collision=True
    assert len(arrow_bounds(fixture_svg))==2
    fixture_layout={**layout,'positions':{'right_end':{'x_mm':200,'y_mm':140}}}
    check=settle_placement(doc,reports,fixture_layout,{}, {'right_end':view})
    assert check['fixture']['arrow_text_clearance_verified']
    assert abs(dim.getRawValue()-diameter)<1e-8
    results.append({'diameter_mm':diameter,'scale':scale,'baseline_collision_detected':baseline_collision,
                    'final_arrow_clearance_verified':True,'native_measurement_unchanged':True,
                    'flipped':dim.ViewObject.FlipArrowheads,'label_position_mm':[dim.X.Value,dim.Y.Value]})
    App.closeDocument(doc.Name)
assert any(r['baseline_collision_detected'] for r in results)
assert any(not r['baseline_collision_detected'] for r in results)
(ROOT/'output/pdf/diameter-layout/fixture-validation.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print('PASSED',len(results),'independent native diameter/scale fixture cases')
