"""Real desktop widget/QProcess integration matrix; no simulated CAD generation.

Run after the complete native suite. The visible app is tested separately through
Windows computer use; this matrix records offscreen Qt event-loop integration.
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
from fastener_gui.window import MainWindow
from fastener_gui.theme import apply_theme
from fastener_gui.state import atomic_json, read_json
from fastener_gui.outputs import sha256, load_release, export_copy


def await_job(window, trigger, limit=1000):
    finished=[]; stages=[]; beats=[]
    def complete(code,result):finished.append((code,result))
    def stage(message):stages.append(message)
    window.backend.completed.connect(complete);window.backend.stage.connect(stage)
    timer=QTimer();timer.setInterval(40);timer.timeout.connect(lambda:beats.append(time.monotonic()));timer.start()
    try:
        trigger()
        if not window.backend.busy:raise AssertionError('Operation did not start: '+window.status.text())
        start=time.monotonic()
        while not finished and time.monotonic()-start<limit:QTest.qWait(50)
        assert finished,'Worker did not finish within bounded integration wait'
        return finished[0], {'stages':stages,'event_loop_heartbeats':len(beats),
                            'largest_heartbeat_gap_seconds':max([b-a for a,b in zip(beats,beats[1:])],default=0),
                            'elapsed_seconds':time.monotonic()-start}
    finally:
        timer.stop();window.backend.completed.disconnect(complete);window.backend.stage.disconnect(stage)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freecad-python',required=True);parser.add_argument('--poppler',required=True)
    args=parser.parse_args()
    app=QApplication([]);apply_theme(app)
    out=ROOT/'output'/'phase5';out.mkdir(exist_ok=True)
    results={'phase':5,'interface_test':'Offscreen Qt widgets and actual QProcess workers; Windows interactive checks recorded separately',
             'matrix':[],'controls':[]}
    window=MainWindow(args.freecad_python,args.poppler,out/'drawings',out/'settings');window.show()
    try:
        for source in sorted((ROOT/'input').glob('*.stp')):
            before=sha256(source);part=source.stem.split('_')[0]
            window.set_source(source)
            (code,result),timing=await_job(window,window.analyze)
            assert code==0 and window.model.catalog,window.backend.last_error
            assert window.generate_button.isEnabled()
            baseline=read_json(ROOT/'output'/(source.stem+'.drawing.json'))
            for mode in ('basic','comprehensive','custom'):
                window.fresh_configuration();window.mode.setCurrentText(mode.title())
                if mode=='custom':
                    ids={key for key,row in baseline['dimensions'].items() if row['status']=='created' and
                         row['candidate']['kind'] in ('overall','diameter','across_flats')}
                    for index,row in enumerate(window.model.catalog['candidates']):
                        window.table.item(index,0).setCheckState(Qt.CheckState.Checked if row['candidate_id'] in ids else Qt.CheckState.Unchecked)
                    window.views['isometric'].setChecked(False)
                    window.sheet.setCurrentText('ANSI-B');window.scale.setCurrentText('2')
                window.metadata['date'].setText(baseline['generated_date'])
                (code,result),timing=await_job(window,window.generate)
                assert code==2 and result['status']=='published_preliminary',window.backend.last_error
                assert 'Completed' in window.status.text() and window.release and window.pdf_button.isEnabled()
                assert window.preview.document.pageCount()==1 and window.preview.path==window.release['pdf']
                release=load_release(result['current_manifest'],source,result['run_id'])
                report=release['report'];created={k:r for k,r in report['dimensions'].items() if r['status']=='created'}
                config=window._read_controls()
                if mode=='custom':
                    assert {r['candidate']['stable_id'] for r in created.values()}==set(config['dimensioning']['include'])
                    assert not {r['candidate']['stable_id'] for r in created.values()} & set(config['dimensioning']['exclude'])
                if mode=='comprehensive':
                    old={k:r for k,r in baseline['dimensions'].items() if r['status']=='created'}
                    assert set(created)==set(old)
                    for key,r in created.items():
                        field='native_value_deg' if r['candidate']['units']=='deg' else 'native_value_mm'
                        assert abs(r['verification'][field]-old[key]['verification'][field])<1e-8
                        assert r['position_relative_to_view_mm']==old[key]['position_relative_to_view_mm']
                    assert report['layout']['positions']==baseline['layout']['positions']
                assert sha256(source)==before
                window.preview.zoom.setCurrentText('200%');assert window.preview.view.zoomFactor()==2
                window.preview.zoom.setCurrentText('Fit To Window')
                exports=out/'exports'/mode;exports.mkdir(parents=True,exist_ok=True)
                for key,ext in [('pdf','.pdf'),('project','.FCStd')]:export_copy(release,key,exports/(part+ext))
                row={'part':part,'mode':mode,'exit_code':code,'dimension_count':len(created),
                     'manifest':result['current_manifest'],'run_id':result['run_id'],'pdf':release['pdf'],'project':release['project'],
                     'source_unchanged':True,'preview_loaded':True,'source_bound_config':True,'export_copies_verified':True,
                     'normalized_and_verified':release['pdf_audit']['status']=='passed','timing':timing,'visual_review':'pending'}
                results['matrix'].append(row);atomic_json(out/'integration_results.json',results)
                print(part,mode,len(created),'dimensions; Qt preview loaded; review exit 2',flush=True)
            # Saved custom policy is restored after a fresh native catalog.
            policy=window._read_controls()
            (code,result),_=await_job(window,window.analyze)
            assert code==0 and window.model.config==policy
            results['controls'].append({'part':part,'reanalyzed_saved_custom_restored':True})
            # Invalid old reference is retained on disk and blocks generation.
            invalid=json.loads(json.dumps(policy));invalid['dimensioning']['include'].append('g1-invalid-saved-reference')
            path=window.store.save(source,invalid);retained=path.read_bytes()
            (code,result),_=await_job(window,window.analyze)
            assert code==0 and window.model.binding_problem and not window.generate_button.isEnabled()
            assert path.read_bytes()==retained
            window.fresh_configuration();window.save_configuration()
            assert window.generate_button.isEnabled()
            results['controls'].append({'part':part,'invalid_saved_selection_preserved_and_blocked':True,'explicit_reset_required':True})

        # Actual safe cancellation while native drawing/export is active. Previous
        # current release remains byte-identical; descendants are job-contained.
        source=sorted((ROOT/'input').glob('*.stp'))[0];window.set_source(source)
        (code,result),_=await_job(window,window.analyze)
        current=out/'drawings'/(source.stem+'.current.json');previous=current.read_bytes()
        def cancel_when_drawing(message):
            if message.startswith('Generating Associative'):QTimer.singleShot(350,window.backend.cancel)
        window.backend.stage.connect(cancel_when_drawing)
        (code,result),timing=await_job(window,window.generate)
        window.backend.stage.disconnect(cancel_when_drawing)
        assert code==3 and result is None and window.preview.path is None
        assert current.read_bytes()==previous and not (out/'drawings'/'.generation.lock').exists()
        results['controls'].append({'real_native_drawing_cancelled':True,'previous_manifest_unchanged':True,
                                   'no_stale_preview':True,'lock_released':True,'timing':timing})
        # Actual failing executable, before publication, not a mocked status.
        window.freecad_edit.setText(str(ROOT/'tmp'/'missing-FreeCAD-python.exe'))
        (code,result),_=await_job(window,window.generate)
        assert code==1 and result is None and current.read_bytes()==previous and window.preview.path is None
        results['controls'].append({'real_backend_failure_exit_1':True,'previous_manifest_unchanged':True,'no_stale_preview':True})
        results['status']='passed_pending_interactive_and_visual_review';atomic_json(out/'integration_results.json',results)
        return 0
    except Exception as error:
        results.update(status='failed',error=str(error));atomic_json(out/'integration_results.json',results)
        print(window.logs.toPlainText()[-6000:],file=sys.stderr)
        raise
    finally:window.close()


if __name__=='__main__':raise SystemExit(main())
