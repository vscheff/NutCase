"""Construct independent test solids; these are synthetic, not vendor samples."""
import sys,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path[:0]=[str(root),str(root/'tests')]
from test_quality import countersunk_pin,shoulder_pin,slotted_round_head,grooved_dowel
from test_analysis import moved
from fastener_analysis.importer import sha256
out=root/'input/fixtures';out.mkdir(parents=True,exist_ok=True)
rows=[]
for maker,length in ((countersunk_pin,27),(shoulder_pin,31),(slotted_round_head,24),(grooved_dowel,35)):
    path=out/(maker.__name__+'.step');shape=moved(maker());shape.exportStep(str(path))
    rows.append({'file':str(path),'sha256':sha256(path),'construction':maker.__name__,'known_overall_length_mm':length,
                 'synthetic':True,'arbitrarily_rotated_and_translated':True})
(out/'manifest.json').write_text(json.dumps({'fixtures':rows,'notice':'Independent synthetic constructions. No claim of real-world generalization; additional independently sourced STEP samples required.'},indent=2),encoding='utf-8')
