"""Execute the two-model mode matrix and source-bound regeneration checks.

Run in external Python after the native suite (shared isolated FreeCAD settings).
The durable evidence is output/phase4/verification_results.json, including errors.
"""
import argparse
import copy
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fastener_drawing.pipeline import ROOT,generate,write_json,digest
from fastener_drawing.configuration import DEFAULT


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--freecad-python',required=True)
    p.add_argument('--poppler',required=True)
    p.add_argument('--reuse-completed',action='store_true',help='Reuse hash-verified complete releases whose source and policy match this matrix')
    a=p.parse_args()
    out=ROOT/'output'/'phase4';out.mkdir(parents=True,exist_ok=True)
    results={'phase':4,'mode_matrix':[], 'additional_controls':[], 'real_world_generalization_claimed':False}
    try:
        for source in sorted((ROOT/'input').glob('*.stp')):
            identifier=source.stem.split('_')[0]
            baseline=read(ROOT/'output'/(source.stem+'.drawing.json'))
            bound=None;catalog=None
            for mode in ('comprehensive','basic','custom'):
                config=copy.deepcopy(DEFAULT) if bound is None else copy.deepcopy(bound)
                config['dimensioning']['mode']=mode
                config['metadata']['date']=baseline['generated_date']
                if mode=='custom':
                    chosen=[r['candidate']['id'] for r in baseline['dimensions'].values() if r['status']=='created'
                            and r['candidate']['kind'] in ('overall','diameter','across_flats')]
                    keys={r['candidate_id']:r['stable_id'] for r in catalog['candidates']}
                    omitted=[r['candidate']['id'] for r in baseline['dimensions'].values() if r['status']=='created' and r['candidate']['id'] not in chosen]
                    config['dimensioning'].update(include=[keys[x] for x in chosen],exclude=[keys[x] for x in omitted])
                    config['views']['isometric']=False
                    config['sheet']['size']='ANSI-B';config['scale']=2
                    config['metadata'].update(title='CUSTOM GEOMETRY REVIEW',drawing_number=identifier,revision='P4')
                config_file=out/(identifier+'.'+mode+'.config.json');write_json(config_file,config)
                current=out/mode/(source.stem+'.current.json')
                result=None
                if a.reuse_completed and current.exists():
                    prior=read(current)
                    try:
                        saved=read(Path(prior['release_directory'])/(source.stem+'.config.json'))
                        proposed=copy.deepcopy(config)
                        if proposed['source_binding'] is None:saved['source_binding']=None
                        prior_report=read(Path(prior['release_directory'])/(source.stem+'.drawing.json'))
                        if saved==proposed and prior_report['phase1_analysis']['source']['sha256_before']==digest(source):
                            assert all(digest(r['path'])==r['sha256'] for r in prior['files'].values())
                            result={'release_directory':prior['release_directory'],'current_manifest':str(current)}
                    except FileNotFoundError:pass  # old experimental paths may exceed MAX_PATH
                if result is None:result=generate(source,out/mode,a.freecad_python,a.poppler,config_file)
                release=Path(result['release_directory']);report=read(release/(source.stem+'.drawing.json'))
                bound=read(release/(source.stem+'.config.json'));catalog=read(release/(source.stem+'.catalog.json'))
                created={k:r for k,r in report['dimensions'].items() if r['status']=='created'}
                row={'part':identifier,'mode':mode,'release_directory':str(release),'current_manifest':result['current_manifest'],
                     'source_sha256':digest(source),'dimension_count':len(created),'created_candidates':list(created),
                     'native_view_count':report['reopen_checks']['native_view_count'],'sheet':report['layout']['sheet'],'scale':report['layout']['scale'],
                     'pdf_verified':True,'normalized_automatically':True,'normalization_changes':sum(len(x['changes']) for x in report['pdf_compatibility']['pages']),
                     'hatch_status':report.get('section_diagnostics',{}).get('hatching',{}).get('status'),
                     'unresolved_dimensions':report['unresolved_dimensions'],'visual_review':'pending'}
                if mode=='comprehensive':
                    old={k:r for k,r in baseline['dimensions'].items() if r['status']=='created'}
                    assert set(old)==set(created),'Comprehensive native dimensions changed'
                    for key,r in created.items():
                        field='native_value_deg' if r['candidate']['units']=='deg' else 'native_value_mm'
                        assert abs(r['verification'][field]-old[key]['verification'][field])<1e-8,key
                        assert r['view_role']==old[key]['view_role'],key
                        assert r['position_relative_to_view_mm']==old[key]['position_relative_to_view_mm'],key
                    assert report['layout']['positions']==baseline['layout']['positions'],'Comprehensive view placement changed'
                    row['baseline_measurements_and_positions_preserved']=True
                if mode=='custom':
                    selected=set(config['dimensioning']['include'])
                    emitted={r['candidate']['stable_id'] for r in created.values()}
                    assert emitted==selected,'Custom requested dimensions did not match emitted dimensions'
                    assert not emitted & set(config['dimensioning']['exclude'])
                    row['exact_custom_selection_verified']=True
                    # Actual regeneration without a supplied config must reuse the
                    # published bound policy, including its explicit exclusions.
                    again=generate(source,out/mode,a.freecad_python,a.poppler)
                    regenerated=read(Path(again['release_directory'])/(source.stem+'.drawing.json'))
                    assert regenerated['configuration']==report['configuration']
                    assert {k for k,r in regenerated['dimensions'].items() if r['status']=='created'}==set(created)
                    row['saved_policy_regeneration_verified']=True
                    row['latest_release_directory']=again['release_directory']
                results['mode_matrix'].append(row)
                write_json(out/'verification_results.json',results)
                print(identifier,mode,len(created),'native dimensions; normalized and verified',flush=True)

            # Invalid selection must fail before any export/publication and keep
            # the previous complete bundle current. The new catalog stays in runs/.
            current=Path(result['current_manifest']);before=current.read_bytes()
            invalid=copy.deepcopy(bound);invalid['dimensioning']['include'].append('g1-no-such-source-geometry')
            file=out/(identifier+'.invalid.config.json');write_json(file,invalid)
            try:generate(source,out/'custom',a.freecad_python,a.poppler,file)
            except RuntimeError as exc:
                assert 'Invalid saved candidate references' in str(exc),str(exc)
            else:raise AssertionError('Invalid saved reference was accepted')
            # result points at the pre-regeneration manifest, which is the same path.
            assert current.read_bytes()==before
            results['additional_controls'].append({'part':identifier,'invalid_saved_reference_rejected':True,'previous_manifest_unchanged':True})

        # Exercise all optional views disabled, manual sheet/scale, source-derived
        # orientation override, metadata and a normalized nonsection PDF.
        source=next((ROOT/'input').glob('*09748*.stp'))
        baseline=read(ROOT/'output'/(source.stem+'.drawing.json'))
        saved_manifest=read(out/'comprehensive'/(source.stem+'.current.json'))
        config=read(Path(saved_manifest['release_directory'])/(source.stem+'.config.json'))
        saved_catalog=read(Path(saved_manifest['release_directory'])/(source.stem+'.catalog.json'))
        overall=next(r['stable_id'] for r in saved_catalog['candidates'] if r['kind']=='overall')
        config['dimensioning'].update(mode='basic',include=[],exclude=[overall])
        config['views']={k:False for k in config['views']}
        config['sheet']['size']='ANSI-B';config['scale']=2.5
        config['orientation']={k:baseline['orientation'][k] for k in ('axis','up')}
        config['metadata'].update(title='REVIEWED VIEW ORIENTATION',drawing_number='VIEW-CONTROL',revision='P4')
        file=out/'optional-views.config.json';write_json(file,config)
        run=generate(source,out/'optional-views',a.freecad_python,a.poppler,file)
        report=read(Path(run['release_directory'])/(source.stem+'.drawing.json'))
        assert set(report['layout']['positions'])=={'longitudinal','right_end'}
        assert report['layout']['sheet']=='ANSI-B' and report['layout']['scale']==2.5
        assert report['reopen_checks']['view_directions_verified']
        assert not any(r['status']=='created' and r['candidate']['kind']=='overall' for r in report['dimensions'].values())
        assert next(r for r in report['dimensions'].values() if r['candidate']['kind']=='overall')['status']=='suppressed_by_configuration'
        results['additional_controls'].append({'optional_views_disabled':True,'manual_scale':2.5,'manual_sheet':'ANSI-B',
            'orientation_source_unchanged':report['source_sha256_verified_unchanged'],'explicit_basic_exclusion_verified':True,
            'release_directory':run['release_directory'],'visual_review':'pending'})
        results['status']='passed_pending_visual_review'
        write_json(out/'verification_results.json',results)
        return 0
    except Exception as exc:
        results.update(status='failed',error=str(exc))
        write_json(out/'verification_results.json',results)
        raise


if __name__=='__main__':raise SystemExit(main())
