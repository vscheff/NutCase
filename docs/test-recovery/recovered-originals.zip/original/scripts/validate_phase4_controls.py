"""Additional real pipeline controls: compatible bytes, changed geometry and exclusion."""
import argparse
import copy
import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fastener_drawing.pipeline import ROOT, generate, write_json, digest


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--freecad-python',required=True)
    p.add_argument('--poppler',required=True)
    a=p.parse_args()
    out=ROOT/'output'/'phase4'
    source=next((ROOT/'input').glob('*09748*.stp'))
    before=digest(source)
    manifest=out/'custom'/(source.stem+'.current.json')
    prior=read(manifest)
    bound=read(Path(prior['release_directory'])/(source.stem+'.config.json'))
    controls=ROOT/'tmp'/'phase4-controls'
    copy_dir=controls/'compatible-source';copy_dir.mkdir(parents=True,exist_ok=True)
    same=copy_dir/source.name
    same.write_bytes(source.read_bytes()+b'\n')
    config_file=out/'compatible-source.config.json';write_json(config_file,bound)
    result=generate(same,out/'compatible-source',a.freecad_python,a.poppler,config_file,catalog_only=True)
    compatible=read(result['config'])
    assert compatible['source_binding']['geometry_id']==bound['source_binding']['geometry_id']
    assert compatible['source_binding']['source_sha256']!=bound['source_binding']['source_sha256']
    assert compatible['dimensioning']==bound['dimensioning']

    changed_dir=controls/'changed-source';changed_dir.mkdir(parents=True,exist_ok=True)
    changed=changed_dir/source.name
    worker=controls/'make_changed.py'
    # Construct a separate control, never rewrite either supplied STEP source.
    worker.write_text('import sys\nimport FreeCAD\nimport Part\nPart.makeCylinder(4,20).exportStep(sys.argv[1])\n',encoding='utf-8')
    made=subprocess.run([a.freecad_python,str(worker),str(changed)],capture_output=True,text=True,timeout=30)
    if made.returncode:raise RuntimeError(made.stdout+made.stderr)
    current=manifest.read_bytes()
    try:generate(changed,out/'custom',a.freecad_python,a.poppler)
    except RuntimeError as exc:
        assert 'Saved source references are incompatible' in str(exc),str(exc)
    else:raise AssertionError('Changed geometry reused old saved references')
    assert manifest.read_bytes()==current
    assert digest(source)==before

    comprehensive=read(out/'comprehensive'/(source.stem+'.current.json'))
    config=read(Path(comprehensive['release_directory'])/(source.stem+'.config.json'))
    catalog=read(Path(comprehensive['release_directory'])/(source.stem+'.catalog.json'))
    overall=next(r['stable_id'] for r in catalog['candidates'] if r['kind']=='overall')
    config['dimensioning'].update(mode='basic',include=[],exclude=[overall])
    config['views']={key:False for key in config['views']}
    config['sheet']['size']='ANSI-B';config['scale']=2.5
    baseline=read(ROOT/'output'/(source.stem+'.drawing.json'))
    config['orientation']={key:baseline['orientation'][key] for key in ('axis','up')}
    config['metadata'].update(title='REVIEWED VIEW ORIENTATION',drawing_number='EXCLUSION-CONTROL',revision='P4')
    file=out/'basic-exclusion.config.json';write_json(file,config)
    existing=out/'optional-views'/(source.stem+'.current.json')
    if existing.exists():
        saved=read(existing)
        report=read(Path(saved['release_directory'])/(source.stem+'.drawing.json'))
        assert all(digest(r['path'])==r['sha256'] for r in saved['files'].values())
        assert report['phase1_analysis']['source']['sha256_before']==before
        result={'release_directory':saved['release_directory']}
    else:
        result=generate(source,out/'basic-exclusion',a.freecad_python,a.poppler,file)
        report=read(Path(result['release_directory'])/(source.stem+'.drawing.json'))
    assert set(report['layout']['positions'])=={'longitudinal','right_end'}
    assert report['layout']['sheet']=='ANSI-B' and report['layout']['scale']==2.5
    overall_row=next(r for r in report['dimensions'].values() if r['candidate']['kind']=='overall')
    assert overall_row['status']=='suppressed_by_configuration' and not overall_row['selected']
    assert not any(r['status']=='created' and r['candidate']['kind']=='overall' for r in report['dimensions'].values())
    assert report['source_sha256_verified_unchanged'] and report['reopen_checks']['view_directions_verified']
    record={'status':'passed_pending_visual_review','compatible_STEP_byte_change_preserves_selection':True,
            'changed_source_geometry_rejected_before_drawing':True,'previous_manifest_unchanged':True,
            'original_STEP_unchanged':True,'explicit_basic_exclusion_verified':True,
            'optional_views_disabled':True,'manual_sheet':'ANSI-B','manual_scale':2.5,
            'orientation_override_verified':True,'release_directory':result['release_directory'],'visual_review':'pending'}
    write_json(out/'additional_controls.json',record)
    print(json.dumps(record,indent=2))


if __name__=='__main__':main()
