"""Native GUI transport checks for external sources, source changes and locking."""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from validate_phase5 import await_job
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from fastener_gui.window import MainWindow
from fastener_gui.theme import apply_theme
from fastener_gui.state import atomic_json
from fastener_gui.outputs import sha256


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freecad-python',required=True);parser.add_argument('--poppler',required=True)
    args=parser.parse_args();app=QApplication([]);apply_theme(app)
    directory=ROOT/'tmp'/'phase5-controls';directory.mkdir(exist_ok=True)
    source=directory/'external-source.step'
    original=next((ROOT/'input').glob('*09748*.stp'));digest=sha256(original)
    shutil.copyfile(original,source)
    window=MainWindow(args.freecad_python,args.poppler,directory/'drawings',directory/'settings');window.show()
    evidence={}
    try:
        window.set_source(source)
        (code,_),_=await_job(window,window.analyze)
        assert code==0
        window.fresh_configuration();window.mode.setCurrentText('Custom')
        assert window.generate_button.isEnabled()
        window.table.item(0,0).setCheckState(Qt.CheckState.Checked)
        (code,result),timing=await_job(window,window.generate)
        assert code==2 and window.preview.document.pageCount()==1
        assert len([r for r in window.release['report']['dimensions'].values() if r['status']=='created'])==1
        evidence['external_source_native_generation']={'passed':True,'run_id':result['run_id'],'timing':timing}
        saved=window.store.path(source);old=saved.read_bytes();identity=window.model.catalog['geometry_id']
        replacement=directory/'changed-fixture.step'
        subprocess.run([args.freecad_python,'-c',
            'import FreeCAD,Part,sys;Part.makeCylinder(4,20).exportStep(sys.argv[1])',str(replacement)],
            check=True,timeout=60,capture_output=True)
        shutil.copyfile(replacement,source)  # Only the disposable copy changes.
        (code,_),_=await_job(window,window.analyze)
        assert code==0 and window.model.catalog['geometry_id']!=identity
        assert window.model.binding_problem and not window.generate_button.isEnabled()
        assert saved.read_bytes()==old and window.preview.path is None
        window.fresh_configuration();window.save_configuration()
        assert window.generate_button.isEnabled() and any(p.read_bytes()==old for p in saved.parent.joinpath('history').glob('*.json'))
        evidence['changed_native_source_binding']={'passed':True,'previous_configuration_archived':True,'explicit_reset_required':True}
        lock=directory/'drawings'/'.generation.lock'
        lock.write_text(json.dumps({'pid':0,'purpose':'controlled lock rejection test'}))
        prior=(directory/'drawings'/(source.stem+'.current.json')).read_bytes()
        try:
            (code,_),_=await_job(window,window.analyze)
            assert code==1 and lock.exists() and window.preview.path is None
            assert (directory/'drawings'/(source.stem+'.current.json')).read_bytes()==prior
            evidence['existing_lock_respected']={'passed':True,'current_manifest_unchanged':True}
        finally:lock.unlink()
        assert sha256(original)==digest
        evidence['original_source_unchanged']=True
        evidence['status']='passed'
        atomic_json(ROOT/'output'/'phase5'/'controls_results.json',evidence)
        print(json.dumps(evidence,indent=2))
    finally:window.close()


if __name__=='__main__':raise SystemExit(main())
